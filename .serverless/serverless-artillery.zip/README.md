# serverless-artillery-test

## 概要
- serverless-artilleryをDockerで使えるようにした


## 使い方
- このリポジトリをクローンして、下記を実行してください
- `docker compose run --rm slsart deploy`
- `docker compose run --rm slsart invoke`

