#! /bin/bash

slsart deploy
